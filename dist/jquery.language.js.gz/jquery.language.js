(function() {
  (function($) {
    var active_language, autodetect_language, initialized, l, set_language;
    $.language = l = function(options) {
      if (arguments.length === 0) {
        l.config();
        return active_language;
      }
      if (typeof arguments[0] === 'string') {
        l.config({
          'active': arguments[0]
        });
      } else {
        l.config(arguments[0]);
      }
      return this;
    };
    active_language = null;
    initialized = false;
    l.options = {
      active: 'auto',
      fallback: 'en',
      available: ['en'],
      urlParam: 'language',
      cookieName: 'language'
    };
    l.config = function(options) {
      var possible_language;
      if (!options && initialized) {
        return l.options;
      }
      l.options = $.extend(l.options, options);
      if (l.options.active === 'auto') {
        possible_language = autodetect_language();
      } else {
        possible_language = l.options.active;
      }
      set_language(possible_language);
      initialized = true;
      return this;
    };
    l.fallback = function() {
      return l.options.fallback;
    };
    autodetect_language = function() {
      return $.url("?" + l.options.urlParam) || $.cookie(l.options.cookieName) || navigator.language || navigator.userLanguage;
    };
    set_language = function(possible_language) {
      var old_language;
      possible_language = l.normalize(possible_language);
      if (active_language === possible_language) {
        return;
      }
      if (!l.is_valid(possible_language)) {
        $('body').trigger('language.invalid', [
          {
            invalid: possible_language,
            active: active_language
          }
        ]);
        if (initialized) {
          return;
        }
        possible_language = l.options.fallback;
      }
      old_language = active_language;
      active_language = possible_language;
      $.cookie(l.options.cookieName, active_language);
      return $('body').trigger('language.change', [
        {
          active: active_language,
          old: old_language
        }
      ]);
    };
    l.is_valid = function(language) {
      return l.options.available.indexOf(language) !== -1;
    };
    return l.normalize = function(language) {
      if (!language || typeof language !== 'string') {
        return null;
      }
      return language.trim().substr(0, 2).toLowerCase();
    };
  })(jQuery);

}).call(this);
